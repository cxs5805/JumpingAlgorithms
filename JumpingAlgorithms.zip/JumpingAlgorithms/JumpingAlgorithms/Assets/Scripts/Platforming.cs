﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platforming : MonoBehaviour
{
    // array (or list?) to hold all platforms
    private GameObject[] platforms;
    private Bounds[] boundaries;

    // we need to keep track of the current platform
    // in order for the player to fall off of it
    // this makes sense because the player can only
    // be standing on EXACTLY ONE platform
    private Bounds currPlatform;

    private Movement movement;

    //private int landTimer;
    //public int landDuration;

	// Use this for initialization
	void Start ()
    {
        // assume midair, so not landed yet
        //landTimer = 0;

        // get movement script
        movement = gameObject.GetComponent<Movement>();

		// populate platforms array
        platforms = GameObject.FindGameObjectsWithTag("Platform");
        boundaries = new Bounds[platforms.Length];

        for (int i = 0; i < platforms.Length; ++i)
        {
            // get all the bounds structs from each platform's AABB collider
            boundaries[i] = platforms[i].GetComponent<Collider2D>().bounds;

            // DEBUG
            Debug.Log("Index " + i + " is " + platforms[i].name +
                "\r\nMin X = " + boundaries[i].min.x +
                "\r\nMax X = " + boundaries[i].max.x +
                "\r\nHeight= " + boundaries[i].max.y);
        }

        // now that platforms array has been populated, just
        // initialize the current platform as null

        // now that currPlatform is a Bounds, this line 
        // generates compiler errors, so I just commented
        // it out
        //currPlatform = null;
        currPlatform = new Bounds(new Vector3(float.MinValue, float.MinValue), new Vector3(float.MinValue, float.MinValue));
        Debug.Log("currPlatform = " + currPlatform);
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (movement.up)
            CheckAllPlatforms();
        else
            CheckCurrPlatform();
	}

    void CheckAllPlatforms()
    {
        foreach (Bounds b in boundaries)
        {
            if
            (
                transform.position.x >= b.min.x &&
                transform.position.x <= b.max.x &&
                transform.position.y <= b.max.y &&
                transform.position.y >= b.min.y //&&
                //movement.vel.y < 0
            )
            {
                // top edge - landing!
                if (movement.vel.y < 0)
                {
                    movement.Land(b.max.y);
                    // DEBUG
                    Debug.Log("Hey, land! and current platform = " + b.ToString());
                    // 7/11/17 - NOW, SET CURRENT PLATFORM HERE
                    currPlatform = b;
                }
                /*
                // bottom edge
                else if (movement.vel.y >= 0)
                {
                    Debug.Log("bottom edge");
                }
                //*/
            }
            /*
            // let's try writing the logic for having the guy fall off
            // the conditions for it to fall off are that
            // A. it's already grounded
            // B. it walks off the left or right edge
            // 7/11/17 - MOVE THIS OUT OF THE FOREACH LOOP
            // BUT STILL CHECK EVERY FRAME
            else if (!movement.up &&
                (transform.position.x < b.min.x ||
                transform.position.x > b.max.x))
            {
                //Debug.Log("You should fall off now");
                //break;
                // now that the conditions are correct for falling off,
                // set up = false!
                //movement.up = false;
            }
            //*/
        }
    }

    void CheckCurrPlatform()
    {
        if
            (
                currPlatform.center.x != float.MinValue &&
                !movement.up &&
                (
                    transform.position.x < currPlatform.min.x ||
                    transform.position.x > currPlatform.max.x
                )
            )
        {
            Debug.Log("You should fall off now");
            //break;
            // now that the conditions are correct for falling off,
            // set up = false!
            movement.up = true;
        }
    }
}
