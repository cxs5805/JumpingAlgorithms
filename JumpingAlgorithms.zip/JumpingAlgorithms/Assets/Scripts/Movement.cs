﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    // actor attributes
    private Vector3 pos;
    private Vector3 vel;
    private Vector3 acc;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void ApplyForce(Vector3 force)
    {

    }
}
