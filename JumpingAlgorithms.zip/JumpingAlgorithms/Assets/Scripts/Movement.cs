﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    // kinematic attributes
    public Vector3 vel;
    public Vector3 acc;
    public float walkSpeed;

    // dynamic attributes
    public float mass;
    public float maxVel;
    public float maxAcc;

    // fun jumping attributes
    public float gravity;
    public float height;
    private float initJumpV; // this = sqrt (2 * gravity * height)

    // flag attributes
    private bool up;
    private bool fastfall;

    // counter attribute for variable height jumping
    private int counter = 0;

    // floor object attribute
    public GameObject floorObj;
    private float floor;

	// Use this for initialization
	void Start ()
    {
        // assume actor spawns in the air
        // so, it's up and fastfalling
        up = true;
        fastfall = true;

        initJumpV = Mathf.Sqrt(2 * gravity * height);
        Debug.Log("initial jumping force magnitude = " + initJumpV);

        floor = floorObj.transform.position.y + 1.7f;
        Debug.Log("floor height = " + floor);
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (up)
        {
            if (fastfall)
            {
                ApplyForce(new Vector3(0f, -3 * gravity)); // apply triple gravity after the peak of a jump
            }
            else
            {
                ApplyForce(new Vector3(0f, -gravity)); // apply force due to gravity
            }
            
        }
        UpdatePos(); // update current position based on previous state
        ProcessInput(); // process input for left/right
    }

    void UpdatePos()
    {
        /*
        // cap acceleration if needed
        if (acc.magnitude > maxAcc)
        {
            acc.Normalize();
            acc *= maxAcc;
        }
        */

        // EULER
        // add velocity to acceleration * delta(t)
        vel += acc * Time.deltaTime;

        /*
        // cap velocity if needed
        if (vel.magnitude > maxVel)
        {
            vel.Normalize();
            vel *= maxVel;
        }
        */

        // add position to velocity * delta(t)
        transform.position += vel * Time.deltaTime;

        // fix position to the floor
        if (transform.position.y <= floor)
        {
            transform.position = new Vector3(transform.position.x, floor); // set position
            acc = Vector3.zero; // not moving, so acceleration is zero
            vel = Vector3.zero;
            up = false;

            // reset counter
            counter = 0;
            
            // new debugging shenanigans, black if grounded
            //GetComponentInChildren<SpriteRenderer>().color = Color.black;
        }
        else
        {
            // white if airborn
            up = true;
            //GetComponentInChildren<SpriteRenderer>().color = Color.white;
        }

        // test for fastfalling
        if (up && vel.y <= 0f)
        {
            fastfall = true;
            GetComponentInChildren<SpriteRenderer>().color = Color.red;
        }
        else
        {
            fastfall = false;
            GetComponentInChildren<SpriteRenderer>().color = Color.blue;
        }
    }

    void ProcessInput()
    {
        // walk left
        if (Input.GetKey(KeyCode.A))
        {
            transform.position = new Vector3(transform.position.x - walkSpeed,
                transform.position.y);
        }
        // walk right
        if (Input.GetKey(KeyCode.D))
        {
            transform.position = new Vector3(transform.position.x + walkSpeed,
                transform.position.y);
        }

        Jump(); // jumping (this is the fun part)
    }

    void ApplyForce(Vector3 force)
    {
        // F = MA
        // A = M/F
        acc += force / mass;
    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.K) && !up)
        {
            // OLD
            // apply jumping force
            //ApplyForce(new Vector3(0f, initJumpV));

            // NEW
            // just change velocity directly and discontinuously
            vel = new Vector3(vel.x, vel.y + initJumpV);
            up = true;

            // get counter started
            ++counter;
        }

        // press and hold for longer jump
        if (Input.GetKey(KeyCode.K) && counter > 0)
        {
            ++counter;
        }
        else
        {
            counter = 0;
        }

        Debug.Log("counter = " + counter);
    }
}
