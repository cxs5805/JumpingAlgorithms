﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    // kinematic attributes
    public Vector3 vel;
    public Vector3 acc;
    public float walkSpeed;

    // dynamic attributes
    public float mass;
    public float maxVel;
    public float maxAcc;

    // fun jumping attributes
    public float gravity;
    public float height;
    private float initJumpV; // this = sqrt (2 * gravity * height)

    // flag attributes
    // jumping
    private bool up;

    // fast-falling
    private bool fastfall;
    public bool doFastfall; // press Alpha1 to toggle whether fastfall acts
    
    // Simon Belmont style jump
    private bool belmont;
    public bool doBelmont; // press Alpha2 to toggle whether belmont acts
    private KeyCode dir; // track current key for direction of belmont jump

    // variable height jumping
    public bool doVar; // press Alpha3 to toggle whether VHJ applies
    private int counter = 0; // keeps track of # of frames button held
    public int maxCounts; // maximum number of count increments before peak

    // floor object attribute
    public GameObject floorObj;
    private float floor;

	// Use this for initialization
	void Start ()
    {
        // assume actor spawns in the air
        // so, it's up and fastfalling if doFastfall
        up = true;
        if (doFastfall)
            fastfall = true;

        // also, assume belmont and fall straight if doBelmont
        dir = KeyCode.None;
        if (doBelmont)
            belmont = true;

        
        initJumpV = Mathf.Sqrt(2 * gravity * height);
        Debug.Log("initial jumping force magnitude = " + initJumpV);

        floor = floorObj.transform.position.y + 1.7f;
        Debug.Log("floor height = " + floor);
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (up)
        {
            if (fastfall)
            {
                ApplyForce(new Vector3(0f, -4.5f * gravity)); // apply triple gravity after the peak of a jump
            }
            else
            {
                ApplyForce(new Vector3(0f, -gravity)); // apply force due to gravity
            }
        }
        UpdatePos(); // update current position based on previous state
        ProcessInput(); // process input for left/right and jumping
    }

    void UpdatePos()
    {
        /*
        // cap acceleration if needed
        if (acc.magnitude > maxAcc)
        {
            acc.Normalize();
            acc *= maxAcc;
        }
        */

        // EULER
        // add velocity to acceleration * delta(t)
        vel += acc * Time.deltaTime;

        /*
        // cap velocity if needed
        if (vel.magnitude > maxVel)
        {
            vel.Normalize();
            vel *= maxVel;
        }
        */

        // add position to velocity * delta(t)
        transform.position += vel * Time.deltaTime;

        // fix position to the floor
        if (transform.position.y <= floor)
        {
            transform.position = new Vector3(transform.position.x, floor);
            acc = Vector3.zero; // not moving, so acceleration is zero
            vel = Vector3.zero; // and velocity to zero
            up = false; // grounded...
            belmont = false; // ...so don't work belmont magic

            // reset counter
            counter = 0;
            
            // new debugging shenanigans, black if grounded
            //GetComponentInChildren<SpriteRenderer>().color = Color.black;
        }
        else
        {
            // white if airborn
            up = true;
            //GetComponentInChildren<SpriteRenderer>().color = Color.white;
        }

        // test for fastfalling
        if (up && vel.y <= 0f && doFastfall)
        {
            fastfall = true;
            //GetComponentInChildren<SpriteRenderer>().color = Color.red;
        }
        else
        {
            fastfall = false;
            //GetComponentInChildren<SpriteRenderer>().color = Color.blue;
        }

        // debug for VAR toggle
        // green if var
        if (doVar)
        {
            GetComponentInChildren<SpriteRenderer>().color = Color.green;
        }
        // red if no var
        else
        {
            GetComponentInChildren<SpriteRenderer>().color = Color.red;
        }
    }

    void ProcessInput()
    {
        // toggle fastfall, belmont, and var
        if (Input.GetKeyDown(KeyCode.Alpha1))
            doFastfall = !doFastfall;
        if (Input.GetKeyDown(KeyCode.Alpha2))
            doBelmont = !doBelmont;
        if (Input.GetKeyDown(KeyCode.Alpha3))
            doVar = !doVar;

        if (!belmont)
            Walk(); // walk by applying a delta(v) in x, independent of y
        Jump(); // jumping (this is the fun part)
    }

    void Toggle(KeyCode key, bool flag)
    {
        if (Input.GetKeyDown(key))
            flag = !flag;
    }

    void ApplyForce(Vector3 force)
    {
        // F = MA
        // A = M/F
        acc += force / mass;
    }

    void Walk()
    {
        dir = KeyCode.None;

        // walk left
        if (Input.GetKey(KeyCode.A))
        {
            transform.position = new Vector3(transform.position.x - walkSpeed,
                transform.position.y);
            dir = KeyCode.A;
        }
        // walk right
        if (Input.GetKey(KeyCode.D))
        {
            transform.position = new Vector3(transform.position.x + walkSpeed,
                transform.position.y);
            dir = KeyCode.D;
        }
    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.K) && !up)
        {
            // OLD
            // apply jumping force
            //ApplyForce(new Vector3(0f, initJumpV));

            // NEW
            // just change velocity directly and discontinuously ONCE
            vel = new Vector3(vel.x, vel.y + initJumpV);
            up = true;

            // get counter started
            ++counter;

            // start belmont
            if (doBelmont)
                belmont = true;
        }

        // variable height jumping (only if flag = true)
        if (doVar)
        {
            // press and hold for longer jump for maxCounts number of frames
            if (Input.GetKey(KeyCode.K) && counter > 0 && counter < maxCounts)
            {
                ++counter;
                vel = new Vector3(vel.x, vel.y + initJumpV);
            }
            else
            {
                counter = 0;
                //belmont = false;
            }
        }
        

        // belmont magic - fix x velocity
        if (belmont)
        {
            if (dir == KeyCode.A)
            {
                transform.position = new Vector3(transform.position.x - walkSpeed,
                    transform.position.y);
            }
            else if (dir == KeyCode.D)
            {
                transform.position = new Vector3(transform.position.x + walkSpeed,
                    transform.position.y);
            }
        }

        Debug.Log("counter = " + counter);
    }
}
