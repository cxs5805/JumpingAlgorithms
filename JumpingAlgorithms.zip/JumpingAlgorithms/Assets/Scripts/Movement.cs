﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    // kinematic attributes
    public Vector3 vel;
    public Vector3 acc;
    public float walkSpeed;

    // dynamic attributes
    public float mass;
    public float maxVel;
    public float maxAcc;
    public float gravity;

    // flag for determining when grounded or not
    private bool up;

	// Use this for initialization
	void Start ()
    {
	}
	
	// Update is called once per frame
	void Update ()
    {
        ApplyForce(new Vector3(0f, gravity));// apply force due to gravity
        UpdatePos(); // update current position based on previous state
        ProcessInput(); // process input for left/right
    }

    void UpdatePos()
    {
        // cap acceleration if needed
        if (acc.magnitude > maxAcc)
        {
            acc.Normalize();
            acc *= maxAcc;
        }

        // EULER
        // add velocity to acceleration * delta(t)
        vel += acc * Time.deltaTime;

        // cap velocity if needed
        if (vel.magnitude > maxVel)
        {
            vel.Normalize();
            vel *= maxVel;
        }

        // add position to velocity * delta(t)
        transform.position += vel * Time.deltaTime;

        // fix position to the floor
        if (transform.position.y <= -2f)
        {
            Debug.Log("CAP");
            transform.position = new Vector3(transform.position.x, -2f);
        }
    }

    void ProcessInput()
    {
        // walk left
        if (Input.GetKey(KeyCode.A))
        {
            transform.position = new Vector3(transform.position.x - walkSpeed,
                transform.position.y);
        }
        // walk right
        if (Input.GetKey(KeyCode.D))
        {
            transform.position = new Vector3(transform.position.x + walkSpeed,
                transform.position.y);
        }

        Jump(); // jumping (this is the fun part)
    }

    void ApplyForce(Vector3 force)
    {
        // F = MA
        // A = M/F
        acc += force / mass;
    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.K))
        {
            // apply jumping force
            //acc = new Vector3(acc.x, acc.y + 0.3f);
            ApplyForce(new Vector3(0f, 1.3f));
        }
    }
}
