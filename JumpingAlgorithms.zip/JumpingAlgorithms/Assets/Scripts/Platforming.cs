﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platforming : MonoBehaviour
{
    // array (or list?) to hold all platforms
    private GameObject[] platforms;
    private Bounds[] boundaries;

    private Movement movement;

    private int landTimer;
    public int landDuration;

	// Use this for initialization
	void Start ()
    {
        // assume midair, so not landed yet
        landTimer = 0;

        // get movement script
        movement = gameObject.GetComponent<Movement>();

		// populate platforms array
        platforms = GameObject.FindGameObjectsWithTag("Platform");
        boundaries = new Bounds[platforms.Length];

        for (int i = 0; i < platforms.Length; ++i)
        {
            // get all the bounds structs from each platform's AABB collider
            boundaries[i] = platforms[i].GetComponent<Collider2D>().bounds;

            // DEBUG
            Debug.Log("Index " + i + " is " + platforms[i].name +
                "\r\nMin X = " + boundaries[i].min.x +
                "\r\nMax X = " + boundaries[i].max.x +
                "\r\nHeight= " + boundaries[i].max.y);
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
		// check collisions with each platform in platforms array
        foreach (Bounds b in boundaries)
        {
            if (transform.position.x >= b.min.x &&
                transform.position.x <= b.max.x &&
                transform.position.y <= b.max.y &&
                transform.position.y >= b.min.y &&
                landTimer <= 0)
            {
                landTimer = 1;
                movement.Land(b.max.y);
                // DEBUG
                //Debug.Log("Hey, land!");
            }
        }

        // increment timer if landed
        if (landTimer >= 1 && landTimer < landDuration)
            ++landTimer;
        // reset timer if total duration has passed
        else if (landTimer >= landDuration)
            landTimer = 0;
	}
}
